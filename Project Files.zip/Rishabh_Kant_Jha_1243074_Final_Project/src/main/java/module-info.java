module com.example.rishabh_kant_jha_1243074_final_project {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.rishabh_kant_jha_1243074_final_project to javafx.fxml;
    exports com.example.rishabh_kant_jha_1243074_final_project;
}